const h1 = document.querySelector('h1')

h1.addEventListener('click',(e)=>{
    h1.innerHTML=`kolorowa jesień`
})